import {Container, createDecorator} from "../../";

import {TYPE} from "./types";

import {MyServiceInterface, MyService} from "./my-service";

const container = new Container();
const inject = createDecorator(container);

container.bind<MyServiceInterface>(TYPE.MyService).to(MyService);

export {container, TYPE, inject};
