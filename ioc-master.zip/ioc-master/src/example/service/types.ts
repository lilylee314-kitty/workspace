export const TYPE = {
    MyService: Symbol("MyService")
};
