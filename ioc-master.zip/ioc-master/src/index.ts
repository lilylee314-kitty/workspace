export {Container} from "./ioc/container";
export {createDecorator, createWire, createResolve, NOCACHE} from "./ioc/inject";