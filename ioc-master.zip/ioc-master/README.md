This library implements dependency injection for javascript.

## Features

## The Container API

### Creating a container

The container is the place where all dependencies get bound to. It is possible to have
multiple container in our project in parallel.

```ts
import {Container} from "myFirstIoc";
const container = new Container();
```

### Binding

#### Binding a class

```ts
container.bind<ServiceInterface>(symbol).to(Service);
```

#### Binding a class in singleton scope

```ts
container.bind<ServiceInterface>(symbol).to(Service).inSingletonScope();
```

#### Binding a factory

```ts
container.bind<ServiceInterface>(symbol).toFactory(() => new Service());
container.bind<string>(symbol).toFactory(() => "just a string");
```

```ts
container.bind<ServiceInterface>(symbol).toFactory(() => new Service()).inSingletonScope();
```

#### Binding a value

```ts
container.bind<ServiceInterface>(symbol).toValue(new Service()); // Bad, should be avoid
container.bind<string>(symbol).toValue("just a string");
container.bind<() => string>(symbol).toValue(() => "i am a function");
```

### Rebinding

```ts
container.rebind<ServiceMock>(symbol).toValue(new ServiceMock());
```

### Removing

```ts
container.remove(symbol);
```

### Getting a dependency
 
```ts
container.get<Interface>(symbol);
```

### Snapshot & Restore

```ts
container.snapshot();
```
```ts
container.restore();
```

## The `inject` Decorator

```ts
import {createDecorator} from "myFirstIoc";
export const inject = createDecorator(container);
```

```ts
class Example {
    @inject(symbol)
    readonly service!: Interface;
    
    method() {
        this.service.doSomething();
    }
}
```

## The `wire()` Function

```ts
import {createWire} from "myFirstIoc";
export const wire = createWire(container);
```

```ts
class Example {
    readonly service!: Interface;
    
    constructor() {
        wire(this, "service", symbol);
    }
    
    method() {
        this.service.doSomething();
    }
}
```

## The `resolve()` Function

```ts
import {createResolve} from "myFirstIoc";
export const resolve = createResolve(container);
```

```ts
class Example {
    private readonly service = resolve<Interface>(symbol);
    
    method() {
        this.service().doSomething();
    }
}
```

```ts
function Example() {
    const service = resolve<Interface>(symbol);
    service().doSomething();
}
```

## The `symbol`

```ts
export const TYPE = {
    "Service" = Symbol("Service"),
    // [...]
}
```

```ts
export const TYPE = {
    "Service" = Symbol.for("Service"),
    // [...]
}
```

## Usage

#### Step 1 - Installing the IoC library

```bash
npm install --save-dev myFirstIoc
``` 

#### Step 2 - Creating symbols for our dependencies

Now we create the folder ***services*** and add the new file ***services/types.ts***:
```ts
export const TYPE = {
    MyService: Symbol("MyService")
};
```

#### Step 3 - Example services

File ***services/my-service.ts***


#### Step 4 - Creating a container

File ***services/container.ts***


#### Step 5 - Injecting dependencies

***example.ts*** file in our source root.

