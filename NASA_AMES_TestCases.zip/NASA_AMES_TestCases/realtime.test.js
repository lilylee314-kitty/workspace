describe("Mock tests", () => {
    test("Check connection function", () => {
        const conn = new WebSocket('ws://localhost:3000/realtime/');
        conn.onerror = (error) => {
            console.log('Error: ' + error);
        };

        conn.onopen = (evt) => {
            let event = new CustomEvent('pointsConnected');
            window.dispatchEvent(event);
        };

        conn.onmessage = (evt) => {
            let event = new CustomEvent('pointsDataReceived', { detail: evt.data });
            window.dispatchEvent(event);
        };

        expect(conn).toBeDefined();
        expect(conn.onerror('')).toBeFalsy();
    })
});