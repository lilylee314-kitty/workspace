const Spacecraft = require('./spacecraft.js')

test('Open MCT updateState function exists, but not called yet.', () => {
	expect(Spacecraft.prototype.updateState).toBeUndefined();
});

test('Run Open MCT updateState with the state', () => {
	expect(Spacecraft.prototype.updateState).toMatchSnapshot();
});

test('Run Open MCT generateTelemetry with the state', () => {
	expect(Spacecraft.prototype.generateTelemetry).toMatchSnapshot();
});
