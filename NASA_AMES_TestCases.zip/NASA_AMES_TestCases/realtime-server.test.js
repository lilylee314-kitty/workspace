const realtimeServer = require('./realtime-server.js')

test('Open MCT real time server return rounter when listening is on.', () => {
	console.log(realtimeServer);
	expect(realtimeServer.rounter).toBeUndefined();

	const spy = jest.spyOn(realtimeServer, 'notifySubscribers');
	realtimeServer.notifySubscribers();
});