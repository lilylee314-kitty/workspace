//Manual mock test for util.js functions
describe("Mock tests", () => {
    test("Sort data by ascending", () => {
        //hard code timestamp data examples
        const timestamp_data = [1612515388430, 1612502023387];
        const sorted = jest.fn((data) => data.sort((a,b) => a - b));   
        expect(sorted(timestamp_data)).toEqual([ 1612502023387, 1612515388430 ]);
    })

    test("Sort data by descending", () => {
        //hard code timestamp data examples
        const timestamp_data = [1612515388430, 1612502023387];
        const sorted = jest.fn((data) => data.sort((a,b) => b - a));   
        expect(sorted(timestamp_data)).toEqual([ 1612515388430, 1612502023387 ]);
    })

    test("Display timestamp with UTC format", () => {
        const time = jest.fn((x) => Date(x).toString());
        expect(time(1612502023387).length).toBe(57);
    })
});

