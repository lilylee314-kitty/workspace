exports.grubMarketBlogPage = class grubMarketBlogPage {

    constructor(page) {
        this.page = page
    }

    async gotoBlogPage(){
        await this.page.goto('https://blog.grubmarket.com/');
    }

}
