exports.tablePage = class TablePage {

    constructor(page) {
        this.page = page
    }

    async gotoYahooFinialPage(){
        await this.page.goto('https://www.cnn.com/account/log-in');
    }

    async login(username, password){
        await this.username_textbox.fill(username)
        await this.password_textbox.fill(password)
        await this.login_button.click()
    }
}
