import { test, expect } from "@playwright/test";

test.describe("Access GrubMarket Food Order Website", () => {

  test.beforeEach(async ({page, isMobile}) => {
    // please fill in necessary code to complete a before Each block
    test.fixme(isMobile, 'Settings page does not work in mobile yet');
  
  });

  test.afterAll(async () => {
    
  });

  test("Get discount code for first time", async ({page}) => {
    //access grubMarket signin page
    await page.goto('https://www.grubmarket.com/welcome#signin');
    
    //Get zip code
    await expect(page.getByText('The Farm Has Never Been Closer')).toBeVisible();
    await expect(page.getByText('Get farm-fresh food delivered to your door all across the US, at prices up to 50')).toBeVisible();
    await page.getByPlaceholder('Your zip code').fill('94582');
    await page.getByRole('button', { name: 'START SHOPPING' }).click();
    
    //Get email address for 20% discount
    await expect(page.getByText('Get an extra 20% off your first order now!')).toBeVisible();
    await page.getByPlaceholder('Email address').fill('lilylee314@hotmail.com');
    await expect(page.getByText('Join the newsletter to access exclusive deals and learn more about our local far')).toBeVisible();
    await page.getByPlaceholder('Email address').click();
    await page.getByRole('button', { name: 'SUBMIT' }).click();
    
    //Get the discount code
    await expect(page.getByText('GRUB20')).toBeVisible();

    //Close the modal
    await page.getByRole('button', { name: 'Close' }).click();
    
  });

  test("Not using discount code", async ({page}) => {
    //access grubMarket signin page
    await page.goto('https://www.grubmarket.com/welcome#signin');
    
    //Get zip code
    await expect(page.getByText('The Farm Has Never Been Closer')).toBeVisible();
    await expect(page.getByText('Get farm-fresh food delivered to your door all across the US, at prices up to 50')).toBeVisible();
    await page.getByPlaceholder('Your zip code').fill('94582');
    await page.getByRole('button', { name: 'START SHOPPING' }).click();
    
    //Get email address for 20% discount
    await expect(page.getByText('Get an extra 20% off your first order now!')).toBeVisible();
    
    await page.getByRole('button', { name: 'No thanks, I don\'t want to save money' }).click();


  });


  
});