import { test, expect } from "@playwright/test";
import { grubMarketBlogPage } from "../../pages/blog";

test.describe("GrubMarket blog page test", () => {

  test.beforeEach(async ({page, isMobile}) => {
    // please fill in necessary code to complete a before Each block
    test.fixme(isMobile, 'Settings page does not work in mobile yet');
  
  });

  //Test case: Please complete a test that extacts a value from a table in given URL
  test("Check all the blog info", async ({page}) => {
     const blog = new grubMarketBlogPage(page)
     await blog.gotoBlogPage()

     // Get page after a specific action (e.g. clicking a link)
     const [newPage] = await Promise.all([
       context.waitForEvent('page'),
       page.click('a[target="_blank"]') // Opens a new tab
    ])
    await newPage.waitForLoadState();
    console.log(await newPage.title());  
  
  });

 });