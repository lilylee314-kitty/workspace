import { test, expect } from "@playwright/test";
import { grubMarketBlogPage } from "../../pages/blog";

test.describe("GrubMarket blog page test", () => {

  test.beforeEach(async ({page, isMobile}) => {
    // please fill in necessary code to complete a before Each block
    test.fixme(isMobile, 'Settings page does not work in mobile yet');
  
  });

  //Test case: Please complete a test that extacts a value from a table in given URL
  test("Check all the blog tab info", async ({page}) => {
     const blog = new grubMarketBlogPage(page)
     await blog.gotoBlogPage()

     await page.getByRole('link', { name: 'Blog', exact: true }).click();

     await page.getByRole('link', { name: 'Recipes' }).click();
     
     await page.getByRole('link', { name: 'Education' }).click();
     
     await page.getByRole('link', { name: 'Recipes' }).click();
     
     await page.getByRole('link', { name: 'Education' }).click();
     
     await page.getByRole('link', { name: 'Producers' }).click();
     
     await page.getByRole('link', { name: 'Press' }).click();
     
     await page.locator('#menu-main-nav').getByRole('link', { name: 'About Us' }).click();
     
  });

 });