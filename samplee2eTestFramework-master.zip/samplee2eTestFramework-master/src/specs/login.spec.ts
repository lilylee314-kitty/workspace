import { test, expect } from "@playwright/test";
import { LoginPage } from "../../pages/login";

test.describe("interview test", () => {

  test.beforeEach(async ({page, isMobile}) => {
    // please fill in necessary code to complete a before Each block
    test.fixme(isMobile, 'Settings page does not work in mobile yet');
  
  });

  test.afterAll(async () => {
    
  });

  //Test case: Please complete a test that logs user in an application with given URL
  //Given URL is CNN
  test("Succeed login with test account", async ({page}) => {
    const Login = new LoginPage(page)

    await Login.gotoLoginPage()
    await expect(page.locator('#login-header')).toHaveText('Log in to your CNN account');
    await Login.login('testAccount@gmail.com', 'Password@123')

  });

  test("Fail login with test account", async ({page}) => {
   const Login = new LoginPage(page)

   await Login.gotoLoginPage()
   await expect(page.locator('#login-header')).toHaveText('Log in to your CNN account');
   await Login.login('testAccount@gmail.com', 'Password@123-1')

 });
  
});