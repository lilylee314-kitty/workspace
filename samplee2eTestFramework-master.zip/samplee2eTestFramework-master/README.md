# interview sample project
This project is to provide a runnable test framework setup in playwright

## to setup the framework:
```sh 
yarn
```
## Recommended IDE: VSCode
## test code challenge questions are in src/specs/sample.specs.ts

